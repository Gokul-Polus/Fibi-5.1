(function (w, d, s) {
    var a = d.getElementsByTagName('head')[0];
    var r = d.createElement('script');
    r.async = 1;
    r.src = s;
    r.setAttribute('id', 'usetifulScript');
    r.dataset.token = "a40950d2d696c81b1cfa0ed3c87d13d2";
    a.appendChild(r);
})(window, document, "https://www.usetiful.com/dist/usetiful.js");